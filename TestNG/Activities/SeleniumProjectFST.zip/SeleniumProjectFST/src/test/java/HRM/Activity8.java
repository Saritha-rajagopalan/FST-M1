package HRM;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class Activity8 {
	WebDriver driver;
	@BeforeMethod
	public void BeforeMethod()	{
		driver = new  FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
	}
   @Test
   public void Test() throws InterruptedException {
		// Enter UserName
		driver.findElement(By.xpath("//input[@name=\"txtUsername\"]")).sendKeys("orange");
		//Enter Password
		driver.findElement(By.xpath("//input[@name=\"txtPassword\"]")).sendKeys("orangepassword123");
		//click on Login button
		driver.findElement(By.xpath("//input[@name=\"Submit\"]")).click();
		String TxtDashboard=driver.findElement(By.xpath("//div[@class=\"head\"]/h1")).getText();
		System.out.println(TxtDashboard);
		AssertJUnit.assertEquals("Dashboard", TxtDashboard);
		Thread.sleep(5000);
		// click on Apply Leave
		driver.findElement(By.xpath("//span[contains(text(),'Apply Leave')]")).click();
		
		Select LeaveType = new Select(driver.findElement(By.xpath("//select[@id='applyleave_txtLeaveType']")));
		LeaveType.selectByIndex(1);
		// Enter Dates
		driver.findElement(By.xpath("//input[@id='applyleave_txtFromDate']")).clear();
		driver.findElement(By.xpath("//input[@id='applyleave_txtFromDate']")).sendKeys("2022-12-27");
		driver.findElement(By.xpath("//input[@id='applyleave_txtToDate']")).clear();
		driver.findElement(By.xpath("//input[@id='applyleave_txtToDate']")).sendKeys("2022-12-28");
		
		// Click on Apply
		
		driver.findElement(By.xpath("//input[@value='Apply']")).click();
		Thread.sleep(5000);
		//click on MyLeave
		driver.findElement(By.xpath("//a[@id='menu_leave_viewMyLeaveList']")).click();
		driver.findElement(By.xpath("//input[@id='calFromDate']")).clear();
		driver.findElement(By.xpath("//input[@id='calToDate']")).clear();
		driver.findElement(By.xpath("//input[@id='calFromDate']")).sendKeys("2022-12-27");
		driver.findElement(By.xpath("//input[@id='calToDate']")).sendKeys("2022-12-28");
		
		driver.findElement(By.xpath("//input[@id='btnSearch']")).click();

		
		List<WebElement> rows = driver.findElements(By.xpath("//*[@id=\"resultTable\"]/tbody/tr"));
		int rowcount = rows.size();
		
		List<WebElement> cols = driver.findElements(By.xpath("//*[@id=\"resultTable\"]/tbody/tr[1]/td"));
		int colcount = cols.size();
		Thread.sleep(5000);
		System.out.println("rows: "+rowcount);
		System.out.println("cols: "+colcount);
		
		for(int rown=1;rown<=rowcount;rown++)
		{
			WebElement cellvalue1=driver.findElement(By.xpath("//*[@id=\"resultTable\"]/tbody/tr"+"["+rown+"]/td"));
		
			if (cellvalue1.getText().equals("2022-12-27 to 2022-12-28")==true)
			{
				WebElement cellvalue2=driver.findElement(By.xpath("//*[@id=\"resultTable\"]/tbody/tr"+"["+rown+"]/td[6]")); 
				
				System.out.println("Status of Applied Leave is "+cellvalue2.getText());
				continue;
			}
			
		}
		
		
		
	}
	@AfterMethod
	public void AfterMethod(){
		driver.close();
	}

}
