package HRM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

@Test
public class Activity6 {
	WebDriver driver;
	@BeforeMethod
	public void BeforeMethod()	{
		driver = new  FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
	}

	public void Test() throws InterruptedException	{
		// Enter UserName
		driver.findElement(By.xpath("//input[@name=\"txtUsername\"]")).sendKeys("orange");
		//Enter Password
		driver.findElement(By.xpath("//input[@name=\"txtPassword\"]")).sendKeys("orangepassword123");
		//click on Login button
		driver.findElement(By.xpath("//input[@name=\"Submit\"]")).click();
		String TxtDashboard=driver.findElement(By.xpath("//div[@class=\"head\"]/h1")).getText();
		System.out.println(TxtDashboard);
		WebElement Dashboard = driver.findElement(By.xpath("//a[@id='menu_directory_viewDirectory']"));
		
		
		Assert.assertTrue(Dashboard.isDisplayed());
		{
			
		}
		if(Dashboard.isEnabled())
		{
			Dashboard.click();
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div[1]/h1")).getText(),"Search Directory");
		}
		
	}	
	
	@AfterMethod
	public void AfterMethod(){
		driver.close();
	}
			
}
