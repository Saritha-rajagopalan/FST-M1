package HRM;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class Activity4 {
	WebDriver driver;
	@BeforeMethod
	public void BeforeMethod()	{
		driver = new  FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
	}

	@Test
	public void Test() throws InterruptedException	{
		// Enter UserName
		driver.findElement(By.xpath("//input[@name=\"txtUsername\"]")).sendKeys("orange");
		//Enter Password
		driver.findElement(By.xpath("//input[@name=\"txtPassword\"]")).sendKeys("orangepassword123");
		//click on Login button
		driver.findElement(By.xpath("//input[@name=\"Submit\"]")).click();
		String TxtDashboard=driver.findElement(By.xpath("//div[@class=\"head\"]/h1")).getText();
		System.out.println(TxtDashboard);
		Assert.assertEquals("Dashboard", TxtDashboard);
		Thread.sleep(5000);
		//click on PIM
		driver.findElement(By.xpath("//a[@id=\"menu_pim_viewPimModule\"]")).click();
		Thread.sleep(5000);
		//click on Add
		driver.findElement(By.xpath("//input[@value=\"Add\"]")).click();
		
		// Enter required fields
		driver.findElement(By.xpath("//input[@name=\"firstName\"]")).sendKeys("John");
		driver.findElement(By.xpath("//input[@name=\"lastName\"]")).sendKeys("Thomas");
		driver.findElement(By.xpath("//input[@value=\"Save\"]")).click();
		
		//search employee
		//click on PIM
		driver.findElement(By.xpath("//a[@id=\"menu_pim_viewPimModule\"]")).click();
		driver.findElement(By.xpath("//input[@name=\"empsearch[employee_name][empName]\"]")).sendKeys("John Thomas");
		driver.findElement(By.xpath("//input[@value=\"Search\"]")).click();
		
		
		String EMPSearchResult=driver.findElement(By.xpath("//*[@id=\"resultTable\"]/tbody/tr/td[3]")).getText();
		System.out.println(EMPSearchResult);
		Assert.assertEquals("John", EMPSearchResult);
			
		
	}
	
	@AfterMethod
	public void AfterMethod(){
		driver.close();
	}

}
