package HRM;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Activity3 {
	WebDriver driver;
	@BeforeMethod
	public void BeforeMethod()	{
		driver = new  FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
	}

	@Test
	public void Test()	{
		// Enter UserName
		driver.findElement(By.xpath("//input[@name=\"txtUsername\"]")).sendKeys("orange");
		//Enter Password
		driver.findElement(By.xpath("//input[@name=\"txtPassword\"]")).sendKeys("orangepassword123");
		//click on Login button
		driver.findElement(By.xpath("//input[@name=\"Submit\"]")).click();
		String TxtDashboard=driver.findElement(By.xpath("//div[@class=\"head\"]/h1")).getText();
		System.out.println(TxtDashboard);
		Assert.assertEquals("Dashboard", TxtDashboard);
		
		
		
	}
	
	@AfterMethod
	public void AfterMethod(){
		driver.close();
	}
}
