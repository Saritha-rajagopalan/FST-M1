package HRM;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Activity2 {
	WebDriver driver;
	
	@BeforeMethod
	 public void BeforeMethod() {
		driver = new FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
				
	}
	
	@Test
	public void Test() {
	String src_img = driver.findElement(By.xpath("//div[@id=\"divLogo\"]/img")).getAttribute("src");
	
	System.out.println("URL of the image is :"+src_img);
			
	}
	
	@AfterMethod
	public void AfterMethod()
	{
		driver.close();
	}

}


