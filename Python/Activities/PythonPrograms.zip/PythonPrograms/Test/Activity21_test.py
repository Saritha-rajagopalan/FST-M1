from ast import Assert


def testsum():
    Sum = 4+9
    assert(Sum == 13)

def testDiff():
    Difference = 20 - 13
    assert(Difference == 7)

def testproduct():
    Product = 4*5
    assert (Product == 21)
    
def testquoitient():
    Quotient = 10/2
    assert (Quotient == 5)
