print("Hello, World!")
myVariable = 5
print (myVariable)
myVariable = 9
print (myVariable)# Output: 9
x = 1    # int
y = 2.8  # float
z = 1j   # complex

print(type(x)) # Output: <class 'int'>
print(type(y)) # Output: <class 'float'>
print(type(z)) # Output: <class 'complex'>
a = "Hello, World!"
print(a[1]) # Output: "e"
b = "Hello, World!"
print(b[2:5]) # Output: "llo"
print(int('500'));