def sum(list1):
    sumoflist = 0
    for x in list1 :
        sumoflist = sumoflist + x
    return sumoflist

list1 = [19,30,40,50,67]

res=sum(list1)
print(res)

