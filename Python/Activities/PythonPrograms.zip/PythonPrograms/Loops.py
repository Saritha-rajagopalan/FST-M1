a = 0 
while a < 5:
  a += 1
  if a == 3:
    break
  print(a)
  fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
  if fruit == "banana":
    continue
  print(fruit) 
for x in range(2,6):
  print(x)