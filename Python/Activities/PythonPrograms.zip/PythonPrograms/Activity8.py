NumberList = list(input('enter the numbers separated by ,:').split(','))

listlen = len(NumberList)

print(listlen)

if NumberList[0] == NumberList[listlen -1] :
    print('True')
else:
  print('False')




