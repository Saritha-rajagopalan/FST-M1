YourList = list(input('Enter the numbers separated by comma').split(','))
sum =0
for number in YourList :
    sum=sum+int(number)
print(sum)