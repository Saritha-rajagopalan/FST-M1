def myfunction(country = "India"):
  print("Printing from my function "+country)

myfunction(country = "Germany")