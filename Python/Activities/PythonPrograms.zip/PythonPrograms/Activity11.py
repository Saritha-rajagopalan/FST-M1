fruit_shop={
    'apple': 30,
    'orange':50,
    'lychi':30,
    'banana':20,
    'kiwi':60

}

CheckFruit = input("Enter the fruit to check availability: ").lower()

if (CheckFruit in fruit_shop):
  print("yes, fruit is available")
else:
  print("No,Fruit is not available")
