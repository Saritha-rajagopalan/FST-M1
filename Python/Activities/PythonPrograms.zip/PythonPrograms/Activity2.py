NumberTest =int( input ("Enter a Number:"))
rem = NumberTest % 2
if (rem == 0):
   print( 'Number is  even')
else:
  print('Number is  odd')