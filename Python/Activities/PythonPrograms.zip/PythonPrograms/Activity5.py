Number = int(input("Enter the number to create the Multiplication Table:"))
for i in range(1,11):
    print(i,'X',Number,'=',i*Number)
    i=i+1



     