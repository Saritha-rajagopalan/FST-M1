List1 = [10,43,56,37,98]
List2 =[8,95,33,45,56]
List3=[]
List4=[]
for x in List1 :
    y=x%2
    if y==0:
        List3.append(x)
    else:
       List4.append(x)
for z in List2 :
    y=z%2
    if y==0:
        List3.append(z)
    else:
       List4.append(z)
print('List3 is ' )
print(List3)

print('List4 is ')
print (List4)


 
  

