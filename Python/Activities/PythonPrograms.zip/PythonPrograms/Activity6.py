for i in range(11):
    print(str(i) * i)
