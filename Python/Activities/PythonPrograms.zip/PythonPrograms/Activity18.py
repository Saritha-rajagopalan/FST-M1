from pickle import FALSE
import pandas
d = pandas.read_csv("sample.csv")
print(d["Usernames"])
print("Username of second row: ")
print(d["Usernames"][1])
print("Password of second row: ")
print(d["Passwords"][1])
print(d.sort_values(["Usernames"]))
print(d.sort_values(["Passwords"],ascending = False))
	
    
