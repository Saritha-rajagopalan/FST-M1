num_tuple=(10,45,23,56,70,85)
for x in num_tuple:
  if x%5==0 :
      print(x)
