Name = input ('Enter your Name:')
Age = int(input ('Enter your age:'))
year = str ((2022-Age)+100)
print ("Hello " + Name + ", You will turn 100 years in "+year)