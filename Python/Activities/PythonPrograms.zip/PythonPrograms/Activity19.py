import pandas
from pandas import ExcelWriter
data = {
    'FirstName' :['Satvik','Avinash','Lahri'],
    'LastName':['shah','Kati','Rath'],
    'Email':['satshah@example.com','avinashk@example.com','lahri.rath@example.com'],
    'Phone':['4537829158','5892184058','4528727830']
    }

DF=pandas.DataFrame(data)
Writer = ExcelWriter("EmpSample.xlsx")
DF.to_excel(Writer,'TestData',index=False)

Writer.save()

