#Use pandas to read data the Excel file

#Print the number of rows and columns
#Print the data in the emails column only
#Sort the data based on FirstName in ascending order and print the data
 

#Hint: You can use DataFrame.shape to get the number of rows and columns

import pandas
from pandas import read_excel

Data = pandas.DataFrame(read_excel("EmpSample.xlsx"))
Row_Cols = Data.shape
print('Number of Rows = ')
print(Row_Cols[0])
print('Number of Cols= ')
print(Row_Cols[1])
print('Emails :')
print(Data['Email'])
print(Data.sort_values('FirstName'))





