import java.util.HashSet;
import java.util.Set;

public class Activity10 {
   public static void main(String[] args)
   {
       Set<String> MySet = new HashSet<String>();
       String Fruits[] = {"Strawberry","Mango","Grapes","Kiwi","Orange","Lichy"};
       for(int i=0;i< Fruits.length;i++)
       {
           MySet.add(Fruits[i]);
       }
       for(String s:MySet)
       {
          System.out.println(s);
       }

       System.out.println("size of the Hash set Myset "+MySet.size());
       MySet.remove("Grapes");

       MySet.remove("Plum");
       System.out.println("Whether the set contains Grapes? :"+MySet.contains("Grapes"));

       for(String s:MySet)
       {
           System.out.println(s);
       }
   }

}
