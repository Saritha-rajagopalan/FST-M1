import sun.misc.IOUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.*;

public class TestUtil {

        public static void main(String[] args) {
            try {
                //Using BufferedReader
                //readUsingTraditionalWay();

                //Using IOUtils
                readUsingIOUtils();
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }

        //reading a file using IOUtils in one go
        public static <in> void readUsingIOUtils() throws IOException {
            try (InputStream in = new FileInputStream("C:\\Users\\782114744\\IdeaProjects\\FST_Java\\Activities\\src\\input.tx"))
                     {

            }

        }

}
