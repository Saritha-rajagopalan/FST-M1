import java.util.ArrayList;

public class Activity9 {
 public static void main(String[] args) {
     ArrayList<String> MyList = new ArrayList<String>();
     MyList.add("Sucy");
     MyList.add("Sam");
     MyList.add("John");
     MyList.add("Kim");
     MyList.add("Tom");
     for (String s : MyList) {
         System.out.println(s);

     }

     System.out.println("Third element in the array is :" + MyList.get(2));
     System.out.println("Check whether sam exists in the array: " + MyList.contains("Sam"));
     System.out.println("size of the array is :" + MyList.size());
     MyList.remove("John");
     System.out.println("size of the array is :" + MyList.size());
 }

}
