public class Activity5 {
    public static void main(String args[]) {
        MyBook NewNovel = new MyBook();

String NameNew="DevilTattoo";
NewNovel.setTitle(NameNew);
System.out.println("Name of the NewNovel is :" + NewNovel.getTitle());

}
}

abstract class Book {
    String title;

    abstract void setTitle(String s);

    public String getTitle() {
        return title;
    }
}

  class MyBook extends Book {
    public void setTitle(String s) {
        title = s;
    }

}





