class CustomException extends Exception
{
    private String message = null;
   CustomException(String s){
       this.message = s;
   }

    @Override
    public String getMessage() {
        return message;
    }
}

public class Activity8 {

    static void exceptionTest(String TestString) throws CustomException
    {
        if(TestString==null)
            throw new CustomException("String value is null");
        else
            System.out.println(" The string value is "+TestString);




    }

    public static void main(String[] args) throws CustomException {
        try {
            Activity8.exceptionTest("Trying with String");
            Activity8.exceptionTest(null);
        }catch(CustomException CE){
            System.out.println ("Inside catch:"+CE.getMessage());
        }
    }
}
