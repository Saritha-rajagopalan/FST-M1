import org.apache.commons.io.FileUtils;
import java.io.File;
import java.io.IOException;

import static org.apache.commons.io.FileUtils.readFileToString;

public class Activity14 {

        public static void main(String[] args) {
            try {
                File file = new File("C:\\Users\\782114744\\IdeaProjects\\Java\\testfile.txt");
                boolean fstatus = file.createNewFile();
                if (fstatus) {
                    System.out.println("File created");

                } else {
                    System.out.println("File creation failed");
                }

                File f = FileUtils.getFile("C:\\Users\\782114744\\IdeaProjects\\Java\\testfile.txt");
                String s = readFileToString(f, "UFT8");
                System.out.println(s);


            } catch (IOException e) {
                System.out.println("File creation failed" + e);
            }

        }
    }
