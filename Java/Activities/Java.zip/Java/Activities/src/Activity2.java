public class Activity2 {
    public static void main(String args[])
    {
        int[] array1 ={10,77,10,54,-11,20};
        int lenarray1 = array1.length;
        int sum=0;
        for (int i=0;i<lenarray1; i++)
        {
            if(array1[i]%10==0)
            {
                sum =sum +array1[i];

            }

        }
        if(sum==30)
        {
            System.out.println("TRUE");
        }
        else
        {
            System.out.println("FALSE");
        }


    }
}
