import java.util.HashMap;

public class Activity11 {
    public static void main(String args[]) {

        HashMap<Integer, String> colors = new HashMap<Integer, String>();
        colors.put(1, "Yellow");
        colors.put(2, "Red");
        colors.put(3, "Orange");
        colors.put(4, "Green");
        colors.put(5, "Blue");

        System.out.println("The Oringinal map is:"+ colors);

        colors.remove(2);
        System.out.println("Green color exists?:" + colors.containsValue("Green"));
        System.out.println("Size of the map is :" + colors.size());
    }

}
