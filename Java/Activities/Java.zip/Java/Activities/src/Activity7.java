
    interface BicycleParts
    {
        public int gears = 0;
        public int speed = 0;
    }

    interface BicycleOperations {
        public void applyBrake(int decrement);
        public void speedUp(int increment);
    }



    class Bicycle implements BicycleParts,BicycleOperations{
        int gear;
        int currentspeed;

        public Bicycle(int gear,int speed)
         {
            this.gear = gear;
            this.currentspeed =speed;
         }

         public void applyBrake(int decrement)
         {
            currentspeed = currentspeed - decrement;
            System.out.println("Current speed after applying break:"+currentspeed);
         }

         public void speedUp(int increment)

         {
             currentspeed = currentspeed +increment;
             System.out.println("Current speed after speed up :"+currentspeed);
         }

         public void bicycleDesc()
         {
             System.out.println("Number of Gears :"+gear);
             System.out.println("Current speed is : "+currentspeed);
         }

     }
     class mountainBike extends Bicycle
     {
         public int seatheight=0;
         public mountainBike(int gear,int speed,int seatheight)
         {
             super(gear,speed);
             this.seatheight=seatheight;
         }

         public void setHeight(int Height)
         {
             seatheight = Height;

         }

         public void bicycleDesc()
         {
             System.out.println("Number of Gears :"+gear);
             System.out.println("Current speed is : "+currentspeed);
             System.out.println("Seat Height is : "+seatheight);
         }
     }

    public class Activity7 {
     public static void main(String[] args)
     {
         mountainBike mB = new mountainBike(5,60,6);
         mB.speedUp(10);
         mB.applyBrake(5);
         mB.setHeight(7);
         mB.bicycleDesc();

     }

}
