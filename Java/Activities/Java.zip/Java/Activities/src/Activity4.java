import java.util.Arrays;

public class Activity4 {

    public static void main(String[] args) {

        int numberarray[] = {29,45,64,38,79,53};
        int  len = numberarray.length;


        for ( int i=1;i<=len-1; i++) {
            int currentElement = numberarray[i];
            int j = i - 1;
            while (j >= 0 && currentElement < numberarray[j]) {
                numberarray[j + 1] = numberarray[j];
                --j;
            }
            numberarray[j + 1] = currentElement;
        }
           System.out.println("The sorted array is: ");
            System.out.println(Arrays.toString(numberarray));





    }


}
