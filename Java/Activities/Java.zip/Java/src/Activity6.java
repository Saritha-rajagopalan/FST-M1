import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



    class Plane {
        private List<String> passengers;
        private int maxPassengers = 0;
        private Date lastTimeTookOf;
        private Date lastTimeLanded;

        public void onboard(String Passenger) {

                this.passengers.add(Passenger);
        }

        public Plane(int MaximumPassengers)
        {
            this.maxPassengers = MaximumPassengers;
            this.passengers = new ArrayList<>();
        }
        public Date SettakeoffDate()
        {
            this.lastTimeTookOf = new Date();
            return lastTimeTookOf;
        }

        public Date SetLandDate() {

            this.lastTimeLanded = new Date();
            return lastTimeLanded;
        }

        public Date getLastTimeLanded()

        {
            return lastTimeLanded;
        }
        public void land() {
            this.lastTimeLanded = new Date();
            this.passengers.clear();
        }

        public List<String> getPassesngers()

        {
            return passengers;
        }

    }

public class Activity6 {


    public static void main(String args[]) throws InterruptedException {
        Plane P = new Plane(10);
        P.onboard("John");
        P.onboard("Nancy");
        P.onboard("Latha");
        System.out.println("Plane took off at: " + P.SettakeoffDate());
        System.out.println("People on the plane: " + P.getPassesngers());
        Thread.sleep(5000);
        P.land();
        System.out.println("Plane Landed on : " + P.getLastTimeLanded());
        System.out.println("People on the plane after landing: " + P.getPassesngers());
    }
}

