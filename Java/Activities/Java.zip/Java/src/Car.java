public class Car {


        String color;
        String transmission;
        int make;
        int tyres;
        int doors;

        Car() {
            tyres = 4;
            doors = 4;
        }

        public void displayCharacteristics() {
            System.out.println("color is " + color);
            System.out.println("transmission is  " + transmission);
            System.out.println("The make of the car is " + make);
            System.out.println("The number of tyres in the car is " + tyres);
            System.out.println("The number of doors in the car is " + doors);
        }

        public void accelarate() {
            System.out.println("The car is moving");
        }

        public void brake() {
            System.out.println("Car has stopped");
        }


    }


